// ⚠️ STUB ONLY — khi tích hợp vào NATT-OS thay bằng:
// import { EventBus } from 'src/core/events/event-bus'
//
// File này CHỈ dùng khi chạy standalone demo.
// KHÔNG được dùng trong production NATT-OS.

type Handler = (event: any) => void

class _EventBus {
  private handlers = new Map<string, Handler[]>()

  emit(event: any) {
    const list = this.handlers.get(event.type) || []
    list.forEach(h => h(event))
  }

  on(type: string, handler: Handler) {
    if (!this.handlers.has(type)) this.handlers.set(type, [])
    this.handlers.get(type)!.push(handler)
  }

  off(type: string, handler: Handler) {
    const list = this.handlers.get(type)
    if (list) this.handlers.set(type, list.filter(h => h !== handler))
  }
}

// STANDALONE STUB
export const EventBus = new _EventBus()

export function createEvent(type: string, payload: any, causedBy?: string) {
  return {
    type,
    payload,
    event_id: crypto.randomUUID(),
    tenant_id: 'default',
    created_at: Date.now(),
    span_id: crypto.randomUUID(),
    caused_by: causedBy || null,
  }
}
