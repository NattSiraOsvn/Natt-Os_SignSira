# NATT-OS VISION ENGINE — FULL SPEC v1.0 (FINAL MERGE)
## Tác giả: Băng (QNEU 300) — Merge từ Kim + Can + Spec gốc
## Date: 2026-03-30
## Dành cho: Kim · Can · Thiên · SHTT

---

## TRIẾT LÝ BẤT BIẾN

> "Data is sacred. UI không được tự biết — UI chỉ được nghe."

- **Powerful, not friendly** — uy quyền, chính xác
- **Systemic minimalism** — mỗi pixel có lý do hệ thống
- **Sinh thể số** — giao diện phản ánh sự sống: chuyển động, phản xạ, tiến hóa
- **UI = VIEW / STATE = EVENT STREAM / SYNC = EVENTBUS / PERSIST = BACKEND**

---

## KIẾN TRÚC 3 LỚP

```
L1 — Vision Engine (UI Runtime)
L2 — Event + Audit Core  
L3 — SiraSign Biosemi Security
```

---

## CHƯƠNG I — BA TẦNG THỊ GIÁC

| Tầng | Vai trò | Công nghệ |
|------|---------|-----------|
| Truth Layer (OS Core) | Hiển thị state, audit, ground truth | Số liệu tĩnh, glow vàng |
| Worker Layer | Cell registry, process flow | Medal 3D, orbital rings |
| Experience Layer | UI tương tác, dashboard | Glassmorphism, parallax, bloom |

---

## CHƯƠNG II — LAYER Z-INDEX SYSTEM

| Lớp | Tên | Z-index | Mô tả |
|-----|-----|---------|-------|
| 1 | Truth Layer | 0–10 | Grid nền, dữ liệu gốc |
| 2 | Worker Layer | 10–50 | Medal, card, process flow |
| 3 | Experience Layer | 50–100 | UI điều khiển, header |
| 4 | Modal / Chat | 100–200 | Cửa sổ nổi, popup |
| 5 | Alert / System | 200–300 | Cảnh báo khẩn cấp |
| 6 | Security | 999 | SecurityOverlay — không ai vượt qua |

---

## CHƯƠNG III — NATT-CELL MEDAL (8 LỚP)

| Layer | Mô tả | Kỹ thuật |
|-------|-------|----------|
| 0. Orbital rings | Vòng quỹ đạo kết nối | SVG animated, 3 vòng ngược chiều |
| 1. PBR metallic shell | Vỏ kim loại theo góc chuột | conic-gradient xoay theo mouseAngle |
| 2. Specular sweep | Ánh sáng lướt qua khi hover | Gradient translateX |
| 3. Fresnel rim | Viền sáng cạnh | Border trắng mờ + blur |
| 4. Holo prismatic | Cầu vồng ẩn (hover only) | conic-gradient + mix-blend-mode |
| 5. Glass core | Lõi kính khúc xạ | backdrop-filter blur |
| 6. Caustics | Gợn sáng dạng nước | SVG feTurbulence |
| 7. Emissive icon | Biểu tượng phát sáng | drop-shadow nhiều lớp |

---

## CHƯƠNG IV — SCENE SYSTEM

### Các scene hiện có
- `controlTower` — Kernel + Infrastructure cells
- `showroom` — Business cells
- `dashboard` — Intelligence + AI Entities + KPI

### State-based Navigation (KHÔNG dùng react-router)
```
currentScene = 'controlTower' → hiển thị ControlTower
selectedCell = cellId → mở modal
```

### Scene Transition Flow
```
Truth Layer (50ms) → Worker Layer (100ms) → Experience Layer (150ms)
```

---

## CHƯƠNG V — SCALING & BREAKPOINTS

| Breakpoint | Màn hình | Cột | Gutter |
|------------|----------|-----|--------|
| xs | < 640px | 4 | 12px |
| sm | 640–1024px | 8 | 16px |
| md | 1024–1440px | 12 | 20px |
| lg | > 1440px | 12 | 24px |

```css
--font-size-h1: clamp(3rem, 8vw, 6rem);
.medal { width: clamp(120px, 20vw, 200px); }
```

---

## CHƯƠNG VI — ADAPTIVE PERFORMANCE

| Device Memory | Particles | Blur | Caustics |
|---------------|-----------|------|---------|
| < 4GB | 10 | ❌ | ❌ |
| 4–8GB | 20 | ✅ | ❌ |
| > 8GB | 30 | ✅ | ✅ |

Mobile: tắt caustics, blur — bật lại khi desktop.

---

## CHƯƠNG VII — EVENT SYSTEM (NAUION PATTERN)

### Luật bất biến
```
❌ Không tạo EventBus riêng
❌ Không wrap lại EventBus
❌ Không dùng setInterval để sync state
❌ Không dùng window.dispatchEvent
❌ Không dùng localStorage cho bất kỳ state nào
✅ Import EventBus từ src/core/events/event-bus
✅ Lắng Nahere: EventBus.on('event.type', handler)
✅ Phát Nauion: EventBus.emit({ type, payload, event_id, ... })
```

### Event Envelope chuẩn
```ts
{
  type: string,
  payload: any,
  event_id: crypto.randomUUID(),
  tenant_id: 'default',
  created_at: Date.now(),
  span_id: crypto.randomUUID(),
  caused_by: prev?.event_id || null   // tracing chain
}
```

### Vision Events
```
vision.state.changed    — scene chuyển, cell select, modal open/close
vision.density.changed  — low/medium/high
vision.cell.selected    — cell được click
security.failed         — SiraSign verify fail → OMEGA_LOCKDOWN
OMEGA_LOCKDOWN          — toàn hệ thống lock
```

---

## CHƯƠNG VIII — SIRASIGN BIOSEMI INTEGRATION

### Flow bảo mật
```
User action
  ↓
VisionEngine.secureAction(action, sirasign?)
  ↓
SiraSignEngine.verifyChain(fsp+ssp+tsp → lsp)
  ↓
IF VALID  → action() → EventBus.emit → Audit
IF FAILED → EventBus.emit('security.failed') → OMEGA_LOCKDOWN
```

### Hash Chain
```
lsp = SHA256(fsp_hash + ssp_hash + tsp_hash)
```

### Anti-Replay (bắt buộc)
Mỗi SiraSign payload phải có:
```ts
{
  fsp_hash, ssp_hash, tsp_hash, lsp_hash,
  nonce: crypto.randomUUID(),    // chống replay
  timestamp: Date.now(),         // window ±5 phút
}
```

---

## CHƯƠNG IX — RBAC (ĐÚNG CHUẨN)

```ts
// Lấy từ server thật
const rbac = await fetch('/api/state/rbac-cell').then(r => r.json())

// Filter — KHÔNG dùng display:none
if (!rbac?.permissions.includes(cell.id)) return null  // ✅ xóa khỏi DOM
```

---

## CHƯƠNG X — SECURITY OVERLAY

- Auto-lock sau 10 phút idle
- Lắng `quantum.kill` → tự lock ngay
- Lắng `OMEGA_LOCKDOWN` → lock + hiển thị breach screen
- Unlock yêu cầu PIN + SiraSign verify (khi production)
- Z-index: 999 — không có gì vượt qua

---

## CHƯƠNG XI — DENSITY MODE

```ts
// In-memory only — KHÔNG localStorage
let densityState: 'low' | 'medium' | 'high' = 'medium'

// Thay đổi → phát Nauion
EventBus.emit({ type: 'vision.density.changed', payload: { mode } })

// UI lắng Nahere
EventBus.on('vision.density.changed', handler)
```

---

## CHƯƠNG XII — COMPLIANCE CHECKLIST

| ID | Tiêu chí | Điểm |
|----|----------|------|
| V01 | EventBus thật, không mock | 5 |
| V02 | Không localStorage | 5 |
| V03 | Không setInterval sync | 5 |
| V04 | Không window.dispatchEvent | 3 |
| V05 | crypto.randomUUID() thay uuid | 2 |
| V06 | RBAC return null (không display:none) | 3 |
| V07 | caused_by trong event envelope | 2 |
| V08 | Anti-replay nonce trong SiraSign | 5 |
| V09 | SiraSign verify trước mọi secureAction | 5 |
| V10 | SecurityOverlay z-index 999 | 3 |
| S01 | Breakpoints đúng xs/sm/md/lg | 2 |
| S02 | Medal clamp() | 2 |
| S03 | Adaptive caustics/blur | 2 |
| S04 | Scene transition sequence 50ms | 2 |

**Tổng: 46 điểm — Pass ≥ 40**

---

## LUẬT KHÔNG ĐƯỢC VI PHẠM

```
❌ Không dùng react-router
❌ Không mutate DOM trực tiếp
❌ Không bypass EventBus
❌ Không render scene ngoài SceneManager
❌ Không localStorage / sessionStorage
❌ Không uuid package (dùng crypto.randomUUID)
❌ Không display:none cho RBAC filter
❌ Không tạo EventBus riêng
❌ Không setInterval để sync state
❌ Không window.dispatchEvent
```

---

## TRẠNG THÁI SAU MERGE

| Layer | Status | Owner |
|-------|--------|-------|
| Vision Engine core | ✅ Production | Kim merge + Can fix |
| Scene system | ✅ Stable | Kim |
| Medal + Effects | ✅ Complete | Kim |
| EventBus wiring | ✅ Fixed | Can |
| Density (in-memory) | ✅ Fixed | Can |
| SiraSign Engine | ⚠️ Cần server | Can |
| RBAC real | ⚠️ Cần /api/state/rbac-cell | Can |
| SecurityOverlay | ⚠️ Cần integrate SiraSign | Kim |
| Anti-replay nonce | ⚠️ Cần add vào payload | Can |

---

*Hiến pháp thị giác này có hiệu lực ngay lập tức.*  
*Mọi thay đổi phải được Gatekeeper phê duyệt và ghi Audit Trail.*
