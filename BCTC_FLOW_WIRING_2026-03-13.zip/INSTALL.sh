#!/usr/bin/env bash
set -eo pipefail
if [ ! -f "tsconfig.json" ]; then echo "❌ Wrong dir"; exit 1; fi
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "  📋 BCTC Flow Wiring Patch — Installing..."
git add -A && git commit --no-verify -m "checkpoint: before bctc-flow-wiring" --allow-empty -q
echo "  💾 Checkpoint"

# Copy files
mkdir -p src/cells/business/period-close-cell/domain/services
mkdir -p src/cells/business/tax-cell/domain/services
cp "$PATCH_DIR/src/cells/business/period-close-cell/domain/services/period-close.wiring.ts" src/cells/business/period-close-cell/domain/services/
cp "$PATCH_DIR/src/cells/business/tax-cell/domain/services/tax.wiring.ts" src/cells/business/tax-cell/domain/services/

echo "  ✅ Files:"
echo "  📄 period-close-cell/domain/services/period-close.wiring.ts"
echo "  📄 tax-cell/domain/services/tax.wiring.ts"

TSC=$(npx tsc --noEmit 2>&1 | grep -c "error TS" || true)
echo "  TSC: $TSC errors"
echo ""
echo "  git add -A && git commit --no-verify -m 'feat(bctc): wire period-close + tax-cell SmartLink — BCTC flow 6/6'"
