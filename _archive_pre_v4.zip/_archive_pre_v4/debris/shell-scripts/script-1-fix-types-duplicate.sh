#!/bin/bash
# SCRIPT 1: Fix duplicate keys trong types.ts
# Băng - Data Integrity Guardian
# Priority: CAO - types.ts là foundation, fix trước

echo "🔧 [SCRIPT 1] Fixing duplicate keys in src/types.ts..."

TYPES_FILE="src/types.ts"

if [ ! -f "$TYPES_FILE" ]; then
  echo "❌ Không tìm thấy $TYPES_FILE"
  exit 1
fi

# Backup trước khi sửa
cp "$TYPES_FILE" "${TYPES_FILE}.bak"
echo "✅ Backup: ${TYPES_FILE}.bak"

# Đếm lỗi trước
echo "📊 Dòng bị trùng trước khi fix:"
grep -n "ADMIN:\|MANAGER:\|STAFF:\|SALES_STAFF:\|AUDITOR:" "$TYPES_FILE" | head -30

# Xem context của đoạn bị trùng để hiểu cấu trúc
echo ""
echo "📋 Context lines 95-120:"
sed -n '95,120p' "$TYPES_FILE"

echo ""
echo "⚠️  Script 1 chỉ PHÂN TÍCH, không tự sửa vì cần xem toàn bộ context."
echo "👉 Anh chạy lệnh sau để xem toàn bộ đoạn UserRole trong types.ts:"
echo "   grep -n 'UserRole\|ADMIN\|MANAGER\|STAFF\|AUDITOR\|VIEWER\|SENIOR' src/types.ts | head -50"
