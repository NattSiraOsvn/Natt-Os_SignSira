#!/bin/bash
# SCRIPT 3: Fix casing conflicts trong warehouse-cell
# Vấn đề: macOS case-insensitive nhưng TypeScript case-sensitive
# Giải pháp: Chuẩn hóa tất cả import về lowercase, xóa file UPPERCASE trùng

echo "🔧 [SCRIPT 3] Fixing warehouse-cell casing conflicts..."

WAREHOUSE_DIR="src/cells/infrastructure/warehouse-cell"

echo "📋 Các file UPPERCASE hiện tại trong warehouse-cell:"
find "$WAREHOUSE_DIR" -name "*WAREHOUSE*" | sort

echo ""
echo "📋 Các file lowercase tương ứng:"
find "$WAREHOUSE_DIR" -name "*warehouse*" | sort

echo ""
echo "🔧 Bước 1: Chuẩn hóa import trong WAREHOUSE.service.ts"
if [ -f "$WAREHOUSE_DIR/application/WAREHOUSE.service.ts" ]; then
  sed -i '' \
    "s|'../entities/WAREHOUSE.entity'|'../entities/warehouse.entity'|g" \
    "$WAREHOUSE_DIR/application/WAREHOUSE.service.ts"
  sed -i '' \
    "s|'../services/WAREHOUSE.engine'|'../services/warehouse.engine'|g" \
    "$WAREHOUSE_DIR/application/WAREHOUSE.service.ts"
  sed -i '' \
    "s|'../value-objects/WAREHOUSE-category.registry'|'../value-objects/warehouse-category.registry'|g" \
    "$WAREHOUSE_DIR/application/WAREHOUSE.service.ts"
  sed -i '' \
    "s|'../infrastructure/ports/WAREHOUSE.contract'|'../infrastructure/ports/warehouse.contract'|g" \
    "$WAREHOUSE_DIR/application/WAREHOUSE.service.ts"
  echo "✅ Fixed imports in WAREHOUSE.service.ts"
fi

echo "🔧 Bước 2: Chuẩn hóa import trong WAREHOUSE.entity.ts (domain)"
if [ -f "$WAREHOUSE_DIR/domain/entities/WAREHOUSE.entity.ts" ]; then
  sed -i '' \
    "s|'../value-objects/WAREHOUSE-category.registry'|'../value-objects/warehouse-category.registry'|g" \
    "$WAREHOUSE_DIR/domain/entities/WAREHOUSE.entity.ts"
  echo "✅ Fixed imports in domain WAREHOUSE.entity.ts"
fi

echo "🔧 Bước 3: Fix index.ts - dùng lowercase imports"
if [ -f "$WAREHOUSE_DIR/index.ts" ]; then
  sed -i '' \
    "s|'./application/WAREHOUSE.service'|'./application/warehouse.service'|g" \
    "$WAREHOUSE_DIR/index.ts"
  sed -i '' \
    "s|'./domain/entities/WAREHOUSE.entity'|'./domain/entities/warehouse.entity'|g" \
    "$WAREHOUSE_DIR/index.ts"
  sed -i '' \
    "s|'./domain/value-objects/WAREHOUSE-category.registry'|'./domain/value-objects/warehouse-category.registry'|g" \
    "$WAREHOUSE_DIR/index.ts"
  echo "✅ Fixed imports in index.ts"
fi

echo "🔧 Bước 4: Fix warehouse-service.ts"
if [ -f "$WAREHOUSE_DIR/warehouse-service.ts" ]; then
  sed -i '' \
    "s|'./application/WAREHOUSE.service'|'./application/warehouse.service'|g" \
    "$WAREHOUSE_DIR/warehouse-service.ts"
  echo "✅ Fixed imports in warehouse-service.ts"
fi

echo "🔧 Bước 5: Fix ports/index.ts"
if [ -f "$WAREHOUSE_DIR/ports/index.ts" ]; then
  sed -i '' \
    "s|'./WAREHOUSE.contract'|'./warehouse.contract'|g" \
    "$WAREHOUSE_DIR/ports/index.ts"
  echo "✅ Fixed imports in ports/index.ts"
fi

echo "🔧 Bước 6: Fix components và services dùng WAREHOUSE-cell (chữ hoa)"
for FILE in \
  "src/components/warehouse-management.tsx" \
  "src/services/warehouse-service.ts"; do
  if [ -f "$FILE" ]; then
    sed -i '' \
      "s|@/cells/infrastructure/WAREHOUSE-cell/application/WAREHOUSE.service|@/cells/infrastructure/warehouse-cell/application/warehouse.service|g" \
      "$FILE"
    echo "✅ Fixed: $FILE"
  fi
done

echo ""
echo "⚠️  LƯU Ý: macOS không thể rename file chỉ thay đổi casing thông thường."
echo "📌 Nếu vẫn còn lỗi casing, cần rename qua git:"
echo "   git mv src/cells/infrastructure/warehouse-cell/application/WAREHOUSE.service.ts \\"
echo "          src/cells/infrastructure/warehouse-cell/application/warehouse.service.ts"
echo "   (Tương tự cho các file WAREHOUSE khác)"
