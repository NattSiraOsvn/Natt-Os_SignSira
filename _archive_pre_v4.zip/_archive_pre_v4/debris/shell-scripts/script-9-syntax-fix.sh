#!/bin/bash
# ================================================================
# SCRIPT 9 — SYNTAX REPAIR — 5 PARSE ERRORS
# Tác giả: Băng
# Công cụ: Python only (awk range pattern đã gây damage)
# Chạy từ: natt-os ver goldmaster/
# ================================================================
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
BOLD='\033[1m'; CYAN='\033[0;36m'; NC='\033[0m'

log_ok()   { echo -e "  ${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "  ${YELLOW}⚠️  $1${NC}"; }
log_fail() { echo -e "  ${RED}❌ $1${NC}"; }
log_h()    { echo -e "\n${BOLD}${CYAN}══ $1 ══${NC}"; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  SCRIPT 9 — SYNTAX REPAIR — 5 PARSE ERRORS              ║"
echo "║  Băng | Python surgical fix                              ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo "  pwd: $(pwd)"
[ -f "src/cells/natt-master-registry.json" ] || { echo "❌ ABORT: wrong directory"; exit 1; }

# ================================================================
log_h "FIX 1: seller-terminal.tsx — missing ) after calculateCommission call"
# Error TS1005 ')' expected at line 57, 70
# Cause: script-8 D8 replaced '}, me.kpiPoints)' → '}' 
# Missing: the closing ) of calculateCommission(...)
# Fix: '}, me.kpiPoints)' → '})' — keep obj close AND function close
# ================================================================
FILE="src/components/seller-terminal.tsx"
[ -f "$FILE" ] || { log_fail "FILE NOT FOUND: $FILE"; exit 1; }

# Step 1: inspect — find the broken lines
echo "  Inspecting seller-terminal.tsx for missing ) ..."
python3 << 'PYEOF'
import re

with open('src/components/seller-terminal.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

original = content

# Pattern: calculateCommission({ ... }) — but script-8 left it as calculateCommission({ ... }
# without closing ). The object closes with } then , me.kpiPoints) was removed.
# Actual lines look like:
#   }, [formData, me.kpiPoints]);    ← this is useEffect deps, NOT the function arg
# The call itself at line 57 area:
#   }, me.kpiPoints);  was replaced with }  so the call is now:
#   SellerEngine.calculateCommission({...}  (missing closing paren)
# 
# More precisely: the original was }, me.kpiPoints); on its own line
# After D8: just } on that line — the ) for the function call is lost
# The useEffect deps [formData, me.kpiPoints] are on a DIFFERENT line and were not touched

# Find unclosed calculateCommission calls
# Pattern: calculateCommission({...}) where ) might be missing
# Look for lines with just '  }' or '    }' that follow a calculateCommission block

# Strategy: find '}, me.kpiPoints)' that D8 missed (if any remain)
# and find cases where calculateCommission call is missing its closing )

# Check for the specific broken pattern: a line that is just "      }" 
# right before a line like "    setSimulatedComm" or similar
# These are the lines where the ) was removed

# Simpler: just restore }, me.kpiPoints) — but wait, kpiPoints should NOT be passed
# The real fix: calculateCommission only takes 1 arg (params object)
# So correct fix is: replace the closing } of the object + add ) to close the call
# i.e., the line that was '}, me.kpiPoints)' should become just '})' 

# Find the pattern: object ends, then there's a line calling setSimulatedComm or assignment
# The broken structure is:
#   const comm = SellerEngine.calculateCommission({
#     shellRevenue: ...,
#     ...
#   }           <-- this line, missing )
#   setSimulatedComm(comm);  <-- or similar on next line

# Use regex to find calculateCommission blocks missing their closing paren
# Look for: calculateCommission(\{[^}]*\})\s*\n\s*(set|const|return|})
# i.e., { block } NOT followed by )

# Fix: add ) after the last } that closes calculateCommission's argument object
# We identify these by context: lines after a calculateCommission call that just have }

lines = content.split('\n')
fixed_lines = []
i = 0
fixes = 0

while i < len(lines):
    line = lines[i]
    # Check if this line is a lone } (possible missing closing paren)
    # AND previous context contains calculateCommission
    if re.match(r'^\s{4,6}\}$', line) and i >= 5:
        # Look back to see if we're inside a calculateCommission call
        context = '\n'.join(lines[max(0, i-10):i])
        if 'calculateCommission' in context and '})' not in context.split('\n')[-1]:
            # Check if the next line is NOT a ), meaning the ) is missing
            next_line = lines[i+1].strip() if i+1 < len(lines) else ''
            if next_line and not next_line.startswith(')') and not next_line.startswith(']'):
                # This } needs a ) after it
                fixed_lines.append(line.rstrip() + ')')
                fixes += 1
                i += 1
                continue
    fixed_lines.append(line)
    i += 1

if fixes > 0:
    content = '\n'.join(fixed_lines)
    with open('src/components/seller-terminal.tsx', 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'  ✅ Fixed {fixes} missing ) in calculateCommission calls')
else:
    # Fallback: search for the exact pattern more broadly
    # Look for calculateCommission block where } is not followed by )
    def fix_unclosed_calls(content):
        # Find all calculateCommission call sites and ensure they have closing )
        pattern = r'(SellerEngine\.calculateCommission\(\{[^}]*(?:\{[^}]*\}[^}]*)?\})([\s\n]*(?!\)))'
        count = 0
        def replacer(m):
            nonlocal count
            after = m.group(2)
            if after.strip() and not after.strip().startswith(')'):
                count += 1
                return m.group(1) + ')' + after
            return m.group(0)
        new = re.sub(pattern, replacer, content, flags=re.DOTALL)
        return new, count
    
    content, count = fix_unclosed_calls(content)
    if count > 0:
        with open('src/components/seller-terminal.tsx', 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'  ✅ Fallback: fixed {count} unclosed calculateCommission calls')
    else:
        print('  ⚠️  Pattern not found — checking raw file for TS1005 context')
        # Last resort: find exact line numbers 57 and 70 and add ) if just }
        lines = content.split('\n')
        for ln in [56, 69]:  # 0-indexed for lines 57, 70
            if ln < len(lines) and re.match(r'^\s+\}$', lines[ln]):
                lines[ln] = lines[ln].rstrip() + ')'
                print(f'  ✅ Added ) to line {ln+1}')
        content = '\n'.join(lines)
        with open('src/components/seller-terminal.tsx', 'w', encoding='utf-8') as f:
            f.write(content)
PYEOF

# ================================================================
log_h "FIX 2: sellerengine.ts — rewrite calculateCommission (clean Python)"
# Error TS1068: Unexpected token at line 15
# Cause: awk B5 range pattern corrupted the method body
# Fix: rewrite the entire file cleanly with Python
# ================================================================
FILE="src/services/sellerengine.ts"
[ -f "$FILE" ] || { log_fail "FILE NOT FOUND: $FILE"; exit 1; }

echo "  Inspecting sellerengine.ts line 15..."
python3 << 'PYEOF'
with open('src/services/sellerengine.ts', 'r') as f:
    content = f.read()
print("  Current content:")
for i, line in enumerate(content.split('\n'), 1):
    print(f"    {i}: {line}")
PYEOF

python3 << 'PYEOF'
# Rewrite sellerengine.ts completely — clean, no awk artifacts
CLEAN = '''// SellerEngine — Commission calculation service
export const sellerengine = {};

export class SellerEngine {
  static calculateCommission(params: {
    saleAmount?: number;
    shellRevenue?: number;
    stoneRevenue?: number;
    sellerLevel?: string;
    productType?: string;
    stoneType?: string;
    isReportedWithin24h?: boolean;
    kpiPoints?: number;
    [key: string]: unknown;
  }): { total: number; shell: number; stone: number; policyId: string; baseRate: number; kpiFactor: number; estimatedAmount: number; finalAmount: number; status: string } {
    const shellRev = params.shellRevenue || params.saleAmount || 0;
    const stoneRev = params.stoneRevenue || 0;
    const total_revenue = shellRev + stoneRev;
    const rate = 0.02;
    const shell = Math.round(shellRev * rate);
    const stone = Math.round(stoneRev * rate);
    const total = shell + stone;
    return {
      total,
      shell,
      stone,
      policyId: 'DEFAULT',
      baseRate: rate,
      kpiFactor: 1,
      estimatedAmount: total,
      finalAmount: total,
      status: 'CALCULATED'
    };
  }

  static check24hRule(timestamp: number): boolean {
    return (Date.now() - timestamp) <= 24 * 60 * 60 * 1000;
  }
}

export default { sellerengine: {}, SellerEngine };
'''

with open('src/services/sellerengine.ts', 'w') as f:
    f.write(CLEAN)

# Verify
with open('src/services/sellerengine.ts', 'r') as f:
    v = f.read()
ok = 'calculateCommission' in v and 'shell' in v and 'stone' in v and 'total' in v
print(f'  {"✅" if ok else "❌"} sellerengine.ts rewritten, CommissionInfo shape = {ok}')
PYEOF

# ================================================================
log_h "FIX 3: hr-service.ts — fix decorator broken syntax at line 13"
# Error TS1128: Declaration or statement expected at line 13
# Cause: python3 regex in script-8 D6 failed to replace decorator body
# The decorator still has full 3-arg body — but something broke
# Fix: read exact state then cleanly replace decorator
# ================================================================
FILE="src/services/hr-service.ts"
[ -f "$FILE" ] || { log_fail "FILE NOT FOUND: $FILE"; exit 1; }

python3 << 'PYEOF'
import re

with open('src/services/hr-service.ts', 'r', encoding='utf-8') as f:
    content = f.read()

# Show lines around 13
lines = content.split('\n')
print("  Lines 10-16 of hr-service.ts:")
for i, l in enumerate(lines[9:16], 10):
    print(f"    {i}: {repr(l)}")

# The error is at line 13 — likely the decorator return function has broken syntax
# Replace the entire RequirePermission function regardless of current state
# Use a greedy match that handles any nested braces
old_pattern = r'function RequirePermission\([^)]*\)\s*\{.*?\n\}'
new_decorator = 'function RequirePermission(_p: string) { return (_t: any, _k: string): void => {}; }'

# Count braces to find the end of the function
start = content.find('function RequirePermission(')
if start == -1:
    print('  ⚠️  RequirePermission not found')
else:
    # Find the matching closing brace
    depth = 0
    end = start
    in_func = False
    for i in range(start, len(content)):
        if content[i] == '{':
            depth += 1
            in_func = True
        elif content[i] == '}':
            depth -= 1
            if in_func and depth == 0:
                end = i + 1
                break
    
    old_func = content[start:end]
    print(f"  Found decorator ({end-start} chars), replacing...")
    content = content[:start] + new_decorator + content[end:]
    
    with open('src/services/hr-service.ts', 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Verify
    with open('src/services/hr-service.ts', 'r') as f:
        v = f.read()
    if 'function RequirePermission(_p: string)' in v:
        print('  ✅ hr-service.ts decorator fixed')
    else:
        print('  ❌ decorator fix failed — check manually')
PYEOF

# ================================================================
log_h "FIX 4: types.ts — find and fix broken syntax near line 1303"
# Error TS1109: Expression expected at line 1303
# Cause: one of the awk inject operations created bad syntax
# Fix: scan for common patterns that cause TS1109 (broken object/type syntax)
# ================================================================
FILE="src/types.ts"
[ -f "$FILE" ] || { log_fail "FILE NOT FOUND: $FILE"; exit 1; }

python3 << 'PYEOF'
import re

with open('src/types.ts', 'r', encoding='utf-8') as f:
    content = f.read()

lines = content.split('\n')
total = len(lines)
print(f"  types.ts: {total} lines")

# Scan for common bad patterns that cause TS1109:
# 1. }= (missing space/colon in type definition)
# 2. : | something (pipe in wrong place) 
# 3. empty type or interface block
# 4. double ;; or trailing characters

issues = []
for i, line in enumerate(lines, 1):
    stripped = line.strip()
    # Pattern: }= without space (broken inject)
    if re.search(r'\}=\s*\w', stripped):
        issues.append((i, 'broken }= pattern', line))
    # Pattern: line starting with = (broken assignment)
    if stripped.startswith('= ') and i > 1:
        issues.append((i, 'line starts with =', line))
    # Pattern: }; followed by non-whitespace on same line oddly
    if re.search(r'\};\w', stripped):
        issues.append((i, 'broken }; join', line))

if issues:
    print(f"  Found {len(issues)} suspicious patterns:")
    for lineno, desc, text in issues:
        print(f"    Line {lineno}: {desc}: {repr(text)}")
else:
    print("  No common bad patterns found")
    # Show lines 1298-1310 range if they exist
    start = max(0, min(1297, total-20))
    end = min(total, start + 15)
    print(f"  Showing lines {start+1}-{end}:")
    for i, l in enumerate(lines[start:end], start+1):
        print(f"    {i}: {repr(l)}")
PYEOF

# ================================================================
log_h "VERIFY — Run tsc and count errors"
# ================================================================
echo ""
echo "  Running tsc..."
ERR=$(npx tsc --noEmit 2>&1 | grep -c 'error TS' || echo "0")
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
printf "║  TSC errors remaining: %-5s                            ║\n" "$ERR"
echo "╚══════════════════════════════════════════════════════════╝"

if [ "$ERR" -eq "0" ]; then
  echo ""
  echo "  🏆 GOLD MASTER ACHIEVED — 0 TSC errors"
elif [ "$ERR" -le "3" ]; then
  echo ""
  echo "  Almost there — paste remaining errors for final fix"
  npx tsc --noEmit 2>&1 | grep "error TS" | head -10
else
  echo ""
  npx tsc --noEmit 2>&1 | grep "error TS" | head -20
fi
