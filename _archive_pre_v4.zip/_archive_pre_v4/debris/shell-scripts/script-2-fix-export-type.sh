#!/bin/bash
# SCRIPT 2: Fix lỗi TS1362 - export type dùng như value
# Những class được dùng với `new` hoặc `.create()` phải export thường, không phải export type

echo "🔧 [SCRIPT 2] Fixing 'export type' → 'export' for classes used as values..."

FIX_COUNT=0

fix_export_type() {
  local FILE=$1
  if [ ! -f "$FILE" ]; then
    echo "⚠️  Không tìm thấy: $FILE"
    return
  fi
  cp "$FILE" "${FILE}.bak"
  # Đổi "export type {" thành "export {" (chỉ dòng nào có class dùng làm value)
  sed -i '' 's/^export type { /export { /g' "$FILE"
  echo "✅ Fixed: $FILE"
  FIX_COUNT=$((FIX_COUNT + 1))
}

# Kernel cells - các index.ts export type nhưng class dùng như value
fix_export_type "src/cells/kernel/audit-cell/domain/entities/index.ts"
fix_export_type "src/cells/kernel/audit-cell/domain/services/index.ts"
fix_export_type "src/cells/kernel/config-cell/domain/entities/index.ts"
fix_export_type "src/cells/kernel/config-cell/domain/services/index.ts"
fix_export_type "src/cells/kernel/monitor-cell/domain/entities/index.ts"
fix_export_type "src/cells/kernel/rbac-cell/domain/entities/index.ts"
fix_export_type "src/cells/kernel/rbac-cell/domain/services/index.ts"
fix_export_type "src/cells/kernel/security-cell/domain/entities/index.ts"
fix_export_type "src/cells/kernel/security-cell/domain/services/index.ts"

echo ""
echo "✅ Tổng: $FIX_COUNT files đã fix export type → export"
echo "🔍 Verify bằng: grep -r 'export type {' src/cells/kernel/ | grep -v '.bak'"
