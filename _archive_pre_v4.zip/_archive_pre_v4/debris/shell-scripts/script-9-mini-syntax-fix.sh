#!/bin/bash

echo "🔧 MINI SYNTAX FIX — FINAL 5 ERRORS"

# 1️⃣ seller-terminal.tsx — fix missing ')'
sed -i '' 's/};$/});/g' src/components/seller-terminal.tsx

# 2️⃣ hr-service.ts — remove stray closing brace at top
awk 'NR==13 && $0=="}" {next} {print}' src/services/hr-service.ts > tmp && mv tmp src/services/hr-service.ts

# 3️⃣ sellerengine.ts — ensure class closed before export
awk '
/export class SellerEngine/ {inClass=1}
inClass && /return {/ {brace=1}
inClass && brace && /};/ {brace=0}
END {}
{print}
' src/services/sellerengine.ts > tmp && mv tmp src/services/sellerengine.ts

# safer: insert missing } before export default if needed
sed -i '' 's/export default/{ }\nexport default/' src/services/sellerengine.ts

# 4️⃣ types.ts — remove stray employee_id outside interface
sed -i '' '/^  employee_id\?: string;$/d' src/types.ts

echo "🧪 Re-run TypeScript..."
npx tsc --noEmit
