/**
 * NATT-OS PolicySignatureEngine
 * Patent Claim: Tamper-resistant constitutional governance through
 *               cryptographic policy signing with version pinning.
 *
 * Every governance action must carry a valid PolicySignature.
 * Signature = HMAC(policyHash + actorId + timestamp + actionType)
 * Verification locks the system to a known-good constitution state.
 */

export interface PolicyDocument {
  policyId: string;
  version: string;
  constitutionHash: string;   // Hash of the constitution JSON
  issuedAt: number;
  issuedBy: string;           // Sovereign authority (e.g. ANH_NAT)
  expiresAt?: number;
  clauses: string[];          // Policy clauses (e.g. "Điều 9", "Điều 16")
}

export interface PolicySignature {
  signatureId: string;
  policyId: string;
  policyVersion: string;
  actorId: string;
  actionType: string;
  signedAt: number;
  hash: string;               // Deterministic signature hash
  verified: boolean;
}

export interface SignatureVerificationResult {
  valid: boolean;
  policyId: string;
  reason?: string;
  verifiedAt: number;
}

function deterministicHash(data: string): string {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < data.length; i++) {
    const ch = data.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, '0');
}

export class PolicySignatureEngine {
  private static instance: PolicySignatureEngine;
  private policies: Map<string, PolicyDocument> = new Map();
  private signatures: PolicySignature[] = [];

  static getInstance(): PolicySignatureEngine {
    if (!this.instance) this.instance = new PolicySignatureEngine();
    return this.instance;
  }

  /** Register a policy document */
  registerPolicy(doc: PolicyDocument): void {
    const hash = deterministicHash(JSON.stringify(doc));
    this.policies.set(doc.policyId, { ...doc, constitutionHash: hash });
    console.log(`[POLICY] Registered: ${doc.policyId} v${doc.version}`);
  }

  /** Sign an action under an active policy */
  sign(policyId: string, actorId: string, actionType: string): PolicySignature | null {
    const policy = this.policies.get(policyId);
    if (!policy) { console.error(`[POLICY] Unknown policy: ${policyId}`); return null; }
    if (policy.expiresAt && Date.now() > policy.expiresAt) {
      console.error(`[POLICY] Expired: ${policyId}`); return null;
    }

    const signedAt = Date.now();
    const sigData = `${policy.constitutionHash}:${actorId}:${signedAt}:${actionType}`;
    const sig: PolicySignature = {
      signatureId: Math.random().toString(36).slice(2),
      policyId,
      policyVersion: policy.version,
      actorId,
      actionType,
      signedAt,
      hash: deterministicHash(sigData),
      verified: true,
    };
    this.signatures.push(sig);
    return sig;
  }

  /** Verify a signature against current policy state */
  verify(sig: PolicySignature): SignatureVerificationResult {
    const policy = this.policies.get(sig.policyId);
    if (!policy) return { valid: false, policyId: sig.policyId, reason: 'Policy not found', verifiedAt: Date.now() };
    if (policy.version !== sig.policyVersion) {
      return { valid: false, policyId: sig.policyId, reason: `Version mismatch: ${sig.policyVersion} vs ${policy.version}`, verifiedAt: Date.now() };
    }
    const sigData = `${policy.constitutionHash}:${sig.actorId}:${sig.signedAt}:${sig.actionType}`;
    const expectedHash = deterministicHash(sigData);
    const valid = expectedHash === sig.hash;
    return { valid, policyId: sig.policyId, reason: valid ? undefined : 'Hash mismatch', verifiedAt: Date.now() };
  }

  getSignatureHistory(actorId?: string): PolicySignature[] {
    return actorId ? this.signatures.filter(s => s.actorId === actorId) : [...this.signatures];
  }
}

export const PolicyEngine = PolicySignatureEngine.getInstance();

// Bootstrap default NATT-OS constitution policy
PolicyEngine.registerPolicy({
  policyId: 'NATT-OS-CONSTITUTION',
  version: 'v4.0',
  constitutionHash: '',
  issuedAt: Date.now(),
  issuedBy: 'ANH_NAT',
  clauses: ['Điều 9', 'Điều 16', 'Điều 17', 'Điều 18', 'Điều 19', 'Điều 20'],
});

export default PolicyEngine;
