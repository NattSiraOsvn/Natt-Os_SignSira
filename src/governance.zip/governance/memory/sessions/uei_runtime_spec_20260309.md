# SmartLink — Runtime Spec
**Version:** 1.0  
**Loại file:** Runtime spec — implementation-ready, code-level  
**Ngày:** 2026-03-09  
**Status:** Chờ Gatekeeper chốt trước khi implement

---

## 1. Files cần chỉnh sửa

```
src/core/smartlink/smartlink.point.ts        ← applyFiberDecay() + hysteresis
src/core/smartlink/smartlink.qneu-bridge.ts  ← FiberSummary interface
src/cells/infrastructure/smartlink-cell/     ← gossipQueue + receiveGossip
```

---

## 2. Constants cần thêm vào smartlink.point.ts

```typescript
const FIBER_DECAY_IDLE_MS      = 7 * 24 * 60 * 60 * 1000
const FIBER_DECAY_RATE_BASE    = 0.10
const FIBER_DECAY_K            = 0.2
const FIBER_LOST_THRESHOLD     = 0.20   // fiberLost (hysteresis low)
const FIBER_DISSOLVE_THRESHOLD = 0.05   // xóa TouchRecord
// FIBER_THRESHOLD = 5 đã có (fiberFormed tại sensitivity ≥ 0.75)
```

---

## 3. applyFiberDecay() — thêm vào SmartLinkPoint

```typescript
private applyFiberDecay(record: TouchRecord, now: number): void {
  const idleMs = now - record.lastTouchAt
  if (idleMs < FIBER_DECAY_IDLE_MS) return

  // Số ticks đã qua (mỗi tick = FIBER_DECAY_IDLE_MS)
  const ticks = Math.floor(idleMs / FIBER_DECAY_IDLE_MS)

  for (let i = 0; i < ticks; i++) {
    const decayRate = FIBER_DECAY_RATE_BASE / (1 + record.touchCount * FIBER_DECAY_K)
    record.sensitivity = Math.max(0, record.sensitivity - decayRate)
  }

  // Hysteresis: fiberLost
  if (record.fiber && record.sensitivity <= FIBER_LOST_THRESHOLD) {
    record.fiber = false
    this.emit('fiberLost', { cellId: this.cellId, targetCellId: record.targetCellId })
  }
}
```

**QUAN TRỌNG — Decay execution model:**
```
Decay chạy theo continuous tick.
applyFiberDecay() được gọi ở ĐẦU touch() trước khi cập nhật sensitivity.
Không dùng setInterval toàn cục — lazy evaluation tại thời điểm touch.

Vòng lặp ticks: tính số ticks đã trôi qua và apply từng tick.
Đây là cách simulate continuous decay mà không cần background process.
```

---

## 4. Dissolve logic — thêm vào touch()

```typescript
touch(targetCellId: string, layers: TouchLayers): TouchRecord | null {
  const now = Date.now()
  const existing = this.touches.get(targetCellId)

  if (existing) {
    // Apply decay TRƯỚC khi reinforce
    this.applyFiberDecay(existing, now)

    // Nếu đã dissolve → xóa và tạo mới
    if (existing.sensitivity < FIBER_DISSOLVE_THRESHOLD) {
      this.touches.delete(targetCellId)
      // fall through để tạo record mới
    } else {
      // Reinforce
      existing.touchCount++
      existing.sensitivity = Math.min(1.0, existing.sensitivity + SENSITIVITY_GROWTH)
      existing.lastTouchAt = now
      existing.layers = layers

      // fiberFormed check
      if (!existing.fiber && existing.sensitivity >= 0.75) {
        existing.fiber = true
        const fiberId = `FIBER-${this.cellId}-${targetCellId}-${now}`
        this.emit('fiberFormed', { fiberId, sourceCell: this.cellId, targetCellId })
        this.gossip({ nodes: [this.cellId, targetCellId], strength: existing.sensitivity, ttl: 3 })
      }

      // gossip nhẹ khi touchCount ≥ 2
      if (existing.touchCount === 2) {
        this.gossip({ nodes: [this.cellId, targetCellId], strength: existing.sensitivity, ttl: 1 })
      }

      return existing
    }
  }

  // Tạo TouchRecord mới
  const record: TouchRecord = {
    targetCellId,
    firstTouchAt: now,
    lastTouchAt: now,
    touchCount: 1,
    sensitivity: SENSITIVITY_GROWTH,
    fiber: false,
    layers
  }
  this.touches.set(targetCellId, record)
  return record
}
```

---

## 5. FiberSummary interface

```typescript
// Thêm vào smartlink.types.ts hoặc smartlink.qneu-bridge.ts
interface FiberSummary {
  nodes: [string, string]   // [sourceCell, targetCell]
  strength: number
  ttl: number
}
```

---

## 6. gossip() + receiveGossip() — SmartLinkCell

```typescript
private gossipQueue: FiberSummary[] = []
private dedupeCache: Set<string> = new Set()

private gossip(summary: FiberSummary): void {
  this.gossipQueue.push(summary)
  // Process async — không block touch()
  queueMicrotask(() => this.processGossipQueue())
}

private processGossipQueue(): void {
  while (this.gossipQueue.length > 0) {
    const summary = this.gossipQueue.shift()!
    const key = `${summary.nodes[0]}-${summary.nodes[1]}-${Math.round(summary.strength * 10)}`

    if (this.dedupeCache.has(key)) continue
    this.dedupeCache.add(key)
    // Clear cache sau 60s để tránh memory leak
    setTimeout(() => this.dedupeCache.delete(key), 60_000)

    // Forward đến neighbors
    if (summary.ttl > 0) {
      this.forwardGossip({ ...summary, ttl: summary.ttl - 1 })
    }
  }
}

receiveGossip(summary: FiberSummary): void {
  const [src, tgt] = summary.nodes
  const point = this.getPoint(src)
  if (!point) return

  const local = point.getTouchRecord(tgt)
  if (local && summary.strength > local.sensitivity) {
    // Update local awareness — không tăng touchCount
    local.sensitivity = Math.min(local.sensitivity + 0.05, summary.strength)
  }

  if (summary.ttl > 0) {
    this.gossip({ ...summary, ttl: summary.ttl - 1 })
  }
}
```

---

## 7. Thứ tự implement

```
Bước 1: Thêm constants vào smartlink.point.ts
Bước 2: applyFiberDecay() — saturating formula + continuous tick model
Bước 3: touch() — gọi applyFiberDecay() ở đầu + dissolve check
Bước 4: FiberSummary interface
Bước 5: gossipQueue + dedupeCache trong SmartLinkCell
Bước 6: gossip() — 2 tầng triggers
Bước 7: receiveGossip() + forward logic
Bước 8: tsc check — 0 new errors
```

---

## 8. Chưa chốt — pending Gatekeeper

```
fiberWeakening gossip trigger: chưa được quyết định trong phiên 2026-03-09
Không implement cho đến khi Gatekeeper chốt.
```

---

*Runtime spec — chỉ chứa implementation detail. Xem architecture_spec cho context kiến trúc.*
