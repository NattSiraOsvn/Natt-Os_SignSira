// customer-cell contracts
