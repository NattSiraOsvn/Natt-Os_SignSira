/**
 * Warehouse Repository Port
 * Cell: WAREHOUSE-cell | Layer: Ports
 */
import { WarehouseItem } from '../domain/entities/warehouse.entity';

export interface IWarehouseRepository {
  findById(id: string): Promise<WarehouseItem | null>;
  save(item: WarehouseItem): Promise<void>;
  delete(id: string): Promise<boolean>;
  findByCategory(category: string): Promise<WarehouseItem[]>;
}
