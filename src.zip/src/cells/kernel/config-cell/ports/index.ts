export * from "./config-cell.contract";
